ESTRUCTURA DE SCRIPTS REFACTORIZADA
====================================

Objetivo:
- Separar la lógica del nivel de la lógica del personaje.
- Organizar los scripts por funcionalidad.
- Evitar dos sistemas de vida distintos.
- Añadir condición de victoria al derrotar al enemigo final.

CARPETAS
========

Audio/
- AudioGlobal.cs: mantiene el audio global entre escenas.
- AudioManager.cs: reproduce sonidos.

Enemies/
- Enemigo.cs: comportamiento de enemigos móviles.
- EnemigoEstatico.cs: comportamiento de enemigos estáticos.
- EnemigoVida.cs: vida y muerte de enemigos. Incluye la opción "Es Enemigo Final".

Level/
- GameManager.cs: puntos, gasto de puntos, game over, victoria y cambio de escena.
- Escenas.cs: cambio simple de escenas.
- CameraController.cs: seguimiento de cámara.

Pickups/
- Coin.cs: recogida de monedas/puntos.
- Vida.cs: recogida de corazones/vidas.

Player/
- MovimientoPersonaje.cs: movimiento, salto, orientación, bloqueo y animación de muerte.
- AtaquePersonaje.cs: ataque del jugador.
- PlayerHealth.cs: única fuente real de vida del jugador.

UI/
- HUD.cs: actualización visual de puntos y vidas.
- Opciones.cs: menú de opciones.
- ShopManager.cs: compra de mejoras.

IMPORTANTE SOBRE LA VIDA DEL JUGADOR
====================================

La vida real del jugador está SOLO en PlayerHealth:
- vidasActuales
- vidasMaximas

GameManager ya no guarda otra vida propia.
Para evitar errores con scripts antiguos, GameManager tiene métodos puente:
- PerderVida()
- RecuperarVida()
- AumentarVidaMaxima(int cantidad)

Pero todos delegan en PlayerHealth.
Esto evita el problema de tener:
- Sistema A: GameManager
- Sistema B: PlayerHealth

Ahora la tienda compra vida llamando a PlayerHealth.Instance.AumentarVidaMaxima(1).
Los enemigos dañan llamando a PlayerHealth.Instance.RecibirDaño().
El HUD lee la vida desde PlayerHealth.

CONDICIÓN DE VICTORIA
=====================

1. Crea un panel en el Canvas llamado VictoryPanel.
2. Déjalo desactivado en el Inspector.
3. Selecciona el objeto que tiene GameManager.
4. Arrastra VictoryPanel al campo "Victory Panel".
5. Selecciona el enemigo final.
6. En su componente EnemigoVida, activa "Es Enemigo Final".

Cuando ese enemigo llegue a 0 de vida:
- Se llama a GameManager.Victoria().
- Se muestra VictoryPanel.
- Se pausa el juego con Time.timeScale = 0.

PASOS EN UNITY
==============

1. Añade PlayerHealth al mismo GameObject donde está MovimientoPersonaje.
2. En los enemigos, asegúrate de tener EnemigoVida si pueden recibir daño.
3. En el enemigo final, marca "Es Enemigo Final".
4. En GameManager, asigna Death Overlay y Victory Panel.
5. En el HUD, arrastra todos los iconos de vida al array "vidas".
6. En ShopManager, asigna Panel Tienda y revisa el precio de vida.

ACTUALIZACION ANIMACIONES
-------------------------
Se ha corregido MovimientoPersonaje para que la animacion de correr solo pueda activarse cuando el personaje esta tocando el suelo.
Mientras el personaje esta en el aire, IsJumping queda activo aunque el jugador mantenga pulsada una tecla de movimiento.
Esto evita el error de ver la carrera en el aire cuando se salta durante una carrera.

Parametros esperados en el Animator del jugador:
- Bool: IsRunning
- Bool: IsJumping
- Trigger: IsDead
- Trigger: IsAttacking

Recomendacion en el Animator:
La transicion hacia Jump debe tener prioridad sobre Run. Si tienes transiciones desde Any State, evita que Run pueda entrar cuando IsJumping sea true.
