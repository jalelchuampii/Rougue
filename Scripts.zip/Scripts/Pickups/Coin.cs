using UnityEngine;

public class Coin : MonoBehaviour
{
    [SerializeField] private int valor = 1;
    [SerializeField] private AudioManager audioManager;
    [SerializeField] private AudioClip sonidoMoneda;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Player"))
        {
            return;
        }

        if (GameManager.Instance != null)
        {
            GameManager.Instance.SumarPuntos(valor);
        }

        if (audioManager != null && sonidoMoneda != null)
        {
            audioManager.ReproducirSonido(sonidoMoneda);
        }

        Destroy(gameObject);
    }
}
