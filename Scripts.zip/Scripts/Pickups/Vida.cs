using UnityEngine;

public class Vida : MonoBehaviour
{
    [SerializeField] private AudioManager audioManager;
    [SerializeField] private AudioClip sonidoVida;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player"))
        {
            return;
        }

        PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();

        if (playerHealth == null)
        {
            return;
        }

        bool vidaRecuperada = playerHealth.RecuperarVida();

        if (vidaRecuperada)
        {
            if (audioManager != null && sonidoVida != null)
            {
                audioManager.ReproducirSonido(sonidoVida);
            }

            Destroy(gameObject);
        }
    }
}
