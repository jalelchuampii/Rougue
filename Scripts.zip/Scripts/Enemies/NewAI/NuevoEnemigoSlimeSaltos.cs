using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NuevoEnemigoSlimeSaltos : NuevoEnemigoBase2D
{
   [Header("Movimiento Slime")]
   [SerializeField] private float fuerzaSaltoX = 4f;
   [SerializeField] private float fuerzaSaltoY = 7f;
   [SerializeField] private float tiempoEntreSaltos = 1.2f;

   [Header("Suelo")]
   [SerializeField] private Transform detectorSuelo;
   [SerializeField] private float radioSuelo = 0.2f;
   [SerializeField] private LayerMask capaSuelo;

   private float siguienteSalto;

   protected override void Mover()
   {
       MirarHaciaJugador();

       if (Time.time < siguienteSalto)
       {
           return;
       }

       if (!EstaEnSuelo())
       {
           return;
       }

       float direccionX = Mathf.Sign(jugador.position.x - transform.position.x);

       rb.velocity = new Vector2(
           direccionX * fuerzaSaltoX,
           fuerzaSaltoY
       );

       if (animator != null)
       {
           animator.SetTrigger("Jump");
       }

       siguienteSalto = Time.time + tiempoEntreSaltos;
   }

   private bool EstaEnSuelo()
   {
       if (detectorSuelo == null)
       {
           return true;
       }

       return Physics2D.OverlapCircle(
           detectorSuelo.position,
           radioSuelo,
           capaSuelo
       );
   }

   private void OnDrawGizmosSelected()
   {
       if (detectorSuelo != null)
       {
           Gizmos.color = Color.green;
           Gizmos.DrawWireSphere(detectorSuelo.position, radioSuelo);
       }
   }
}
