using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public abstract class NuevoEnemigoBase2D : MonoBehaviour
{
   [Header("Detección")]
   [SerializeField] protected float radioDeteccion = 6f;

   [Header("Ataque")]
   [SerializeField] private float cooldownAtaque = 1f;

   protected Transform jugador;
   protected Rigidbody2D rb;
   protected SpriteRenderer spriteRenderer;
   protected Animator animator;

   protected bool aturdido;
   private bool puedeAtacar = true;

   protected virtual void Awake()
   {
       rb = GetComponent<Rigidbody2D>();
       spriteRenderer = GetComponent<SpriteRenderer>();
       animator = GetComponent<Animator>();
   }

   protected virtual void Start()
   {
       GameObject objJugador = GameObject.FindGameObjectWithTag("Player");

       if (objJugador != null)
       {
           jugador = objJugador.transform;
       }
   }

   protected virtual void FixedUpdate()
   {
       if (jugador == null || aturdido)
       {
           return;
       }

       float distancia = Vector2.Distance(transform.position, jugador.position);

       if (distancia <= radioDeteccion)
       {
           Mover();
       }
       else
       {
           Detener();
       }
   }

   protected abstract void Mover();

   protected virtual void Detener()
   {
       rb.velocity = new Vector2(0f, rb.velocity.y);
   }

   public IEnumerator Aturdir(float tiempo)
   {
       aturdido = true;
       rb.velocity = Vector2.zero;

       yield return new WaitForSeconds(tiempo);

       aturdido = false;
   }

   protected void MirarHaciaJugador()
   {
       if (jugador == null || spriteRenderer == null)
       {
           return;
       }

       spriteRenderer.flipX = jugador.position.x < transform.position.x;
   }

   private void OnCollisionEnter2D(Collision2D other)
   {
       IntentarAtacarJugador(other.gameObject);
   }

   private void OnCollisionStay2D(Collision2D other)
   {
       IntentarAtacarJugador(other.gameObject);
   }

   private void IntentarAtacarJugador(GameObject jugadorObj)
   {
       if (!puedeAtacar || !jugadorObj.CompareTag("Player"))
       {
           return;
       }

       PlayerHealth playerHealth = jugadorObj.GetComponent<PlayerHealth>();

       if (playerHealth == null || !playerHealth.PuedeRecibirDaño())
       {
           return;
       }

       puedeAtacar = false;
       CambiarTransparencia(0.5f);
       playerHealth.RecibirDaño();

       Invoke(nameof(ReactivarAtaque), cooldownAtaque);
   }

   private void ReactivarAtaque()
   {
       puedeAtacar = true;
       CambiarTransparencia(1f);
   }

   private void CambiarTransparencia(float alpha)
   {
       if (spriteRenderer == null)
       {
           return;
       }

       Color color = spriteRenderer.color;
       color.a = alpha;
       spriteRenderer.color = color;
   }

   private void OnDrawGizmosSelected()
   {
       Gizmos.color = Color.red;
       Gizmos.DrawWireSphere(transform.position, radioDeteccion);
   }
}
