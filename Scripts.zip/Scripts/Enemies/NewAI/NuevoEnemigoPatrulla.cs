using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NuevoEnemigoPatrulla : NuevoEnemigoBase2D
{
    [Header("Patrulla")]
    [SerializeField] private float velocidad = 2f;
    [SerializeField] private Transform puntoIzquierda;
    [SerializeField] private Transform puntoDerecha;

    private int direccion = 1;

    protected override void FixedUpdate()
    {
        if (aturdido)
        {
            return;
        }

        Mover();
    }

    protected override void Mover()
    {
        rb.velocity = new Vector2(direccion * velocidad, rb.velocity.y);

        if (direccion > 0 && transform.position.x >= puntoDerecha.position.x)
        {
            direccion = -1;
        }
        else if (direccion < 0 && transform.position.x <= puntoIzquierda.position.x)
        {
            direccion = 1;
        }

        if (spriteRenderer != null)
        {
            spriteRenderer.flipX = direccion < 0;
        }
    }
}