using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NuevoEnemigoDash : NuevoEnemigoBase2D
{
   [Header("Dash")]
   [SerializeField] private float velocidadDash = 10f;
   [SerializeField] private float duracionDash = 0.25f;
   [SerializeField] private float tiempoEntreDashes = 1.5f;

   private bool haciendoDash;
   private float siguienteDash;

   protected override void Mover()
   {
       MirarHaciaJugador();

       if (haciendoDash)
       {
           return;
       }

       if (Time.time >= siguienteDash)
       {
           StartCoroutine(HacerDash());
       }
   }

   private IEnumerator HacerDash()
   {
       haciendoDash = true;

       Vector2 direccion = (jugador.position - transform.position).normalized;
       rb.velocity = new Vector2(direccion.x * velocidadDash, rb.velocity.y);

       if (animator != null)
       {
           animator.SetTrigger("Dash");
       }

       yield return new WaitForSeconds(duracionDash);

       rb.velocity = new Vector2(0f, rb.velocity.y);

       siguienteDash = Time.time + tiempoEntreDashes;
       haciendoDash = false;
   }
}

