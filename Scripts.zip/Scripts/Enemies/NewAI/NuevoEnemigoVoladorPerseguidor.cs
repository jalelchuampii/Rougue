using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NuevoEnemigoVoladorPerseguidor : NuevoEnemigoBase2D
{
   [Header("Vuelo")]
   [SerializeField] private float velocidad = 3f;
   [SerializeField] private float distanciaMinima = 0.8f;

   protected override void Mover()
   {
       MirarHaciaJugador();

       Vector2 direccion = jugador.position - transform.position;

       if (direccion.magnitude <= distanciaMinima)
       {
           rb.velocity = Vector2.zero;
           return;
       }

       rb.velocity = direccion.normalized * velocidad;
   }

   protected override void Detener()
   {
       rb.velocity = Vector2.zero;
   }
}

