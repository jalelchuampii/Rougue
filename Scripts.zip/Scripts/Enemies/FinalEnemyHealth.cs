using UnityEngine;

public class FinalEnemyHealth : MonoBehaviour
{
    [Header("Vida")]
    [SerializeField] private int vida = 5;

    private Animator animator;
    private Rigidbody2D rb;
    private bool muerto = false;

    private void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }

    public void RecibirDaño(int daño)
    {
        if (muerto)
            return;

        vida -= daño;

        // Animación de golpe
        if (animator != null)
        {
            animator.SetTrigger("Hit");
        }

        // Muerte
        if (vida <= 0)
        {
            Morir();
        }
    }

    private void Morir()
    {
        muerto = true;

        // Animación de muerte
        if (animator != null)
        {
            animator.SetTrigger("Dead");
        }

        // Desactivar collider
        Collider2D col = GetComponent<Collider2D>();
        if (col != null)
        {
            col.enabled = false;
        }

        // Parar física
        if (rb != null)
        {
            rb.velocity = Vector2.zero;
            rb.simulated = false;
        }

        // Victoria
        GameManager gameManager = FindFirstObjectByType<GameManager>();

        if (gameManager != null)
        {
            gameManager.Victoria();
        }

        Destroy(gameObject, 0.5f);
    }
}