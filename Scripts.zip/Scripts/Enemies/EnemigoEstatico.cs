using UnityEngine;

public class EnemigoEstatico : MonoBehaviour
{
    [SerializeField] private float cooldownAtaque = 1f;

    private bool puedeAtacar = true;

    private void OnCollisionEnter2D(Collision2D other)
    {
        IntentarAtacarJugador(other.gameObject);
    }

    private void OnCollisionStay2D(Collision2D other)
    {
        IntentarAtacarJugador(other.gameObject);
    }

    private void IntentarAtacarJugador(GameObject jugadorObj)
    {
        if (!puedeAtacar || !jugadorObj.CompareTag("Player"))
        {
            return;
        }

        PlayerHealth playerHealth = jugadorObj.GetComponent<PlayerHealth>();

        if (playerHealth == null || !playerHealth.PuedeRecibirDaño())
        {
            return;
        }

        puedeAtacar = false;
        playerHealth.RecibirDaño();
        Invoke(nameof(ReactivarAtaque), cooldownAtaque);
    }

    private void ReactivarAtaque()
    {
        puedeAtacar = true;
    }
}
