using UnityEngine;

public class EnemigoVida : MonoBehaviour
{
    [Header("Vida")]
    public int vida = 3;

    [Header("Enemigo final")]
    [SerializeField] private bool esEnemigoFinal = false;

    [Header("Knockback")]
    public float distanciaEmpuje = 1.5f;
    public float tiempoAturdido = 1f;

    private Animator animator;
    private Rigidbody2D rb;
    private Enemigo enemigo;

    private bool muerto = false;

    void Start()
    {
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        enemigo = GetComponent<Enemigo>();
    }

    public void RecibirDaño(int daño, Vector2 origenGolpe)
    {
        if (muerto)
            return;

        vida -= daño;

        // Animación de golpe
        if (animator != null)
        {
            animator.SetTrigger("Hit");
        }

        // Empuje hacia atrás
        Vector2 direccion =
            ((Vector2)transform.position - origenGolpe).normalized;

        transform.position += new Vector3(
            direccion.x * distanciaEmpuje,
            0f,
            0f
        );

        // Aturdimiento
        if (enemigo != null)
        {
            StartCoroutine(
                enemigo.Aturdir(tiempoAturdido)
            );
        }

        // Muerte
        if (vida <= 0)
        {
            Morir();
        }
    }

    void Morir()
    {
        muerto = true;

        if (animator != null)
        {
            animator.SetTrigger("Dead");
        }

        Collider2D col = GetComponent<Collider2D>();

        if (col != null)
        {
            col.enabled = false;
        }

        if (rb != null)
        {
            rb.velocity = Vector2.zero;
            rb.simulated = false;
        }

        if (esEnemigoFinal && GameManager.Instance != null)
        {
            GameManager.Instance.Victoria();
        }

        Destroy(gameObject, 0.5f);
    }
}