using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Enemigo : MonoBehaviour
{
    [Header("Ataque")]
    [SerializeField] private float cooldownAtaque = 1f;

    [Header("Movimiento")]
    [SerializeField] private float velocidad = 3f;
    [SerializeField] private float radioDeteccion = 5f;

    private Transform jugador;
    private SpriteRenderer spriteRenderer;
    private Rigidbody2D rb;
    private bool puedeAtacar = true;
    private bool aturdido;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        GameObject objJugador = GameObject.FindGameObjectWithTag("Player");

        if (objJugador != null)
        {
            jugador = objJugador.transform;
        }
    }

    private void FixedUpdate()
    {
        if (jugador == null || aturdido)
        {
            return;
        }

        float distancia = Vector2.Distance(transform.position, jugador.position);

        if (distancia <= radioDeteccion)
        {
            Vector2 direccion = (jugador.position - transform.position).normalized;
            rb.velocity = new Vector2(direccion.x * velocidad, rb.velocity.y);
        }
        else
        {
            rb.velocity = new Vector2(0f, rb.velocity.y);
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        IntentarAtacarJugador(other.gameObject);
    }

    private void OnCollisionStay2D(Collision2D other)
    {
        IntentarAtacarJugador(other.gameObject);
    }

    public IEnumerator Aturdir(float tiempo)
    {
        aturdido = true;
        rb.velocity = new Vector2(0f, rb.velocity.y);
        yield return new WaitForSeconds(tiempo);
        aturdido = false;
    }

    private void IntentarAtacarJugador(GameObject jugadorObj)
    {
        if (!puedeAtacar || !jugadorObj.CompareTag("Player"))
        {
            return;
        }

        PlayerHealth playerHealth = jugadorObj.GetComponent<PlayerHealth>();

        if (playerHealth == null || !playerHealth.PuedeRecibirDaño())
        {
            return;
        }

        puedeAtacar = false;
        CambiarTransparencia(0.5f);
        playerHealth.RecibirDaño();
        Invoke(nameof(ReactivarAtaque), cooldownAtaque);
    }

    private void ReactivarAtaque()
    {
        puedeAtacar = true;
        CambiarTransparencia(1f);
    }

    private void CambiarTransparencia(float alpha)
    {
        if (spriteRenderer == null)
        {
            return;
        }

        Color color = spriteRenderer.color;
        color.a = alpha;
        spriteRenderer.color = color;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, radioDeteccion);
    }
}
