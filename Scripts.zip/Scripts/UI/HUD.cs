using TMPro;
using UnityEngine;

public class HUD : MonoBehaviour
{
    public static HUD Instance { get; private set; }

    [Header("Puntos")]
    [SerializeField] private TextMeshProUGUI puntos;

    [Header("Vidas")]
    [SerializeField] private GameObject[] vidas;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        if (GameManager.Instance != null)
        {
            ActualizarPuntos(GameManager.Instance.PuntosTotales);
        }

        if (PlayerHealth.Instance != null)
        {
            ActualizarVidas(PlayerHealth.Instance.VidasActuales, PlayerHealth.Instance.VidasMaximas);
        }
    }

    public void ActualizarPuntos(int puntosTotales)
    {
        if (puntos != null)
        {
            puntos.text = puntosTotales.ToString();
        }
    }

    public void ActualizarVidas(int vidasActuales, int vidasMaximas)
    {
        for (int i = 0; i < vidas.Length; i++)
        {
            vidas[i].SetActive(i < vidasActuales && i < vidasMaximas);
        }
    }

    public void DesactivarVida(int indice)
    {
        if (IndiceValido(indice))
        {
            vidas[indice].SetActive(false);
        }
    }

    public void ActivarVida(int indice)
    {
        if (IndiceValido(indice))
        {
            vidas[indice].SetActive(true);
        }
    }

    private bool IndiceValido(int indice)
    {
        return indice >= 0 && indice < vidas.Length;
    }
}
