using UnityEngine;

public class ShopManager : MonoBehaviour
{
    [Header("Tienda")]
    [SerializeField] private GameObject panelTienda;

    [Header("Precios")]
    [SerializeField] private int precioVida = 10;

    private bool tiendaAbierta = false;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            ToggleShop();
        }
    }

    public void ToggleShop()
    {
        tiendaAbierta = !tiendaAbierta;

        if (panelTienda != null)
        {
            panelTienda.SetActive(tiendaAbierta);
        }

        Time.timeScale = tiendaAbierta ? 0f : 1f;
    }

    public void ComprarVida()
    {
        if (GameManager.Instance == null || PlayerHealth.Instance == null)
        {
            Debug.LogWarning("Falta GameManager o PlayerHealth en la escena.");
            return;
        }

        bool comprado = GameManager.Instance.GastarPuntos(precioVida);

        if (comprado)
        {
            PlayerHealth.Instance.AumentarVidaMaxima(1);
            Debug.Log("Vida comprada");
        }
        else
        {
            Debug.Log("No tienes suficientes monedas");
        }
    }
}
