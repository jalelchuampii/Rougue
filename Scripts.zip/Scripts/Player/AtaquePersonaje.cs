using System.Collections;
using UnityEngine;

public class AtaquePersonaje : MonoBehaviour
{
    [Header("Ataque")]
    [SerializeField] private Transform puntoAtaque;
    [SerializeField] private float radioAtaque = 0.5f;
    [SerializeField] private LayerMask capaEnemigos;
    [SerializeField] private int dañoAtaque = 1;

    [Header("Cooldown")]
    [SerializeField] private float duracionAtaque = 0.5f;

    [Header("Referencias")]
    [SerializeField] private Animator animator;
    [SerializeField] private AudioManager audioManager;
    [SerializeField] private AudioClip sonidoEspada;

    private bool puedeAtacar = true;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.C) && puedeAtacar)
        {
            StartCoroutine(Atacar());
        }
    }

    private IEnumerator Atacar()
    {
        puedeAtacar = false;

        if (animator != null)
        {
            animator.SetTrigger("IsAttacking");
        }

        if (audioManager != null && sonidoEspada != null)
        {
            audioManager.ReproducirSonido(sonidoEspada);
        }

        Collider2D[] enemigos = Physics2D.OverlapCircleAll(
            puntoAtaque.position,
            radioAtaque,
            capaEnemigos
        );

        foreach (Collider2D enemigo in enemigos)
        {
            // ENEMIGOS NORMALES
            EnemigoVida vidaEnemigo = enemigo.GetComponent<EnemigoVida>();
            if (vidaEnemigo != null)
            {
                vidaEnemigo.RecibirDaño(dañoAtaque, transform.position);
            }

            // JEFE FINAL
            FinalEnemyHealth boss = enemigo.GetComponent<FinalEnemyHealth>();
            if (boss != null)
            {
                boss.RecibirDaño(dañoAtaque);
            }
        }

        yield return new WaitForSeconds(duracionAtaque);
        puedeAtacar = true;
    }

    private void OnDrawGizmosSelected()
    {
        if (puntoAtaque == null)
        {
            return;
        }

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(puntoAtaque.position, radioAtaque);
    }
}