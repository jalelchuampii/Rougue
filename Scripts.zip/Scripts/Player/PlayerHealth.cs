using System.Collections;
using UnityEngine;

[RequireComponent(typeof(MovimientoPersonaje))]
public class PlayerHealth : MonoBehaviour
{
    public static PlayerHealth Instance { get; private set; }

    [Header("Vida")]
    [SerializeField] private int vidasMaximas = 5;
    [SerializeField] private int vidasActuales;

    [Header("Daño")]
    [SerializeField] private float fuerzaGolpe = 10f;
    [SerializeField] private float tiempoInvulnerable = 1f;

    [Header("Audio")]
    [SerializeField] private AudioManager audioManager;
    [SerializeField] private AudioClip sonidoGolpe;

    private MovimientoPersonaje movimiento;
    private SpriteRenderer spriteRenderer;
    private bool esInvulnerable;
    private bool estaMuerto;

    public int VidasActuales => vidasActuales;
    public int VidasMaximas => vidasMaximas;
    public bool EstaMuerto => estaMuerto;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        movimiento = GetComponent<MovimientoPersonaje>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        vidasActuales = vidasMaximas;
        ActualizarHUD();
    }

    public bool PuedeRecibirDaño()
    {
        return !esInvulnerable && !estaMuerto;
    }

    public void RecibirDaño()
    {
        if (!PuedeRecibirDaño())
        {
            return;
        }

        vidasActuales = Mathf.Max(vidasActuales - 1, 0);
        ActualizarHUD();

        AplicarGolpe();

        if (vidasActuales <= 0)
        {
            Morir();
        }
    }

    public bool RecuperarVida()
    {
        if (vidasActuales >= vidasMaximas || estaMuerto)
        {
            return false;
        }

        vidasActuales++;
        ActualizarHUD();
        return true;
    }

    public void AumentarVidaMaxima(int cantidad)
    {
        if (cantidad <= 0)
        {
            return;
        }

        vidasMaximas += cantidad;
        vidasActuales = Mathf.Min(vidasActuales + cantidad, vidasMaximas);
        ActualizarHUD();
    }

    private void AplicarGolpe()
    {
        StartCoroutine(Invulnerabilidad());
        movimiento.BloquearMovimiento();

        Vector2 direccionGolpe = movimiento.RigidBody.velocity.x > 0f
            ? new Vector2(-1f, 1f)
            : new Vector2(1f, 1f);

        movimiento.RigidBody.velocity = Vector2.zero;

        if (audioManager != null && sonidoGolpe != null)
        {
            audioManager.ReproducirSonido(sonidoGolpe);
        }

        movimiento.RigidBody.AddForce(direccionGolpe * fuerzaGolpe, ForceMode2D.Impulse);
        StartCoroutine(EsperarYActivarMovimiento());
    }

    private IEnumerator Invulnerabilidad()
    {
        esInvulnerable = true;
        float tiempo = 0f;

        while (tiempo < tiempoInvulnerable)
        {
            if (spriteRenderer != null)
            {
                spriteRenderer.enabled = !spriteRenderer.enabled;
            }

            yield return new WaitForSeconds(0.1f);
            tiempo += 0.1f;
        }

        if (spriteRenderer != null)
        {
            spriteRenderer.enabled = true;
        }

        esInvulnerable = false;
    }

    private IEnumerator EsperarYActivarMovimiento()
    {
        yield return new WaitForSeconds(0.1f);

        while (!movimiento.EstaEnSuelo() && !estaMuerto)
        {
            yield return null;
        }

        movimiento.PermitirMovimiento();
    }

    private void Morir()
    {
        if (estaMuerto)
        {
            return;
        }

        estaMuerto = true;
        movimiento.Morir();

        if (GameManager.Instance != null)
        {
            GameManager.Instance.GameOver();
        }
    }

    private void ActualizarHUD()
    {
        if (HUD.Instance != null)
        {
            HUD.Instance.ActualizarVidas(vidasActuales, vidasMaximas);
        }
    }
}
