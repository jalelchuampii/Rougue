using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(BoxCollider2D))]
public class MovimientoPersonaje : MonoBehaviour
{
    [Header("Movimiento")]
    [SerializeField] private float velocidad = 5f;

    [Header("Salto")]
    [SerializeField] private float fuerzaSalto = 10f;
    [SerializeField] private int saltosMaximos = 2;

    [Header("Suelo")]
    [SerializeField] private LayerMask capaSuelo;

    [Header("Audio")]
    [SerializeField] private AudioManager audioManager;
    [SerializeField] private AudioClip sonidoSalto;

    private Rigidbody2D rigidBody;
    private BoxCollider2D boxCollider;
    private Animator animator;

    private bool mirandoDerecha = true;
    private int saltosRestantes;
    private bool puedeMoverse = true;
    private bool estaMuerto = false;
    private float inputMovimiento;

    public Rigidbody2D RigidBody => rigidBody;
    public bool EstaMuerto => estaMuerto;

    private void Awake()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        boxCollider = GetComponent<BoxCollider2D>();
        animator = GetComponent<Animator>();
        saltosRestantes = saltosMaximos;
    }

    private void Update()
    {
        if (estaMuerto)
        {
            return;
        }

        inputMovimiento = Input.GetAxisRaw("Horizontal");

        ProcesarSalto();
        ActualizarAnimaciones();
    }

    private void FixedUpdate()
    {
        if (estaMuerto)
        {
            return;
        }

        ProcesarMovimiento();
    }

    public void BloquearMovimiento()
    {
        puedeMoverse = false;
        rigidBody.velocity = new Vector2(0f, rigidBody.velocity.y);

        if (animator != null)
        {
            animator.SetBool("IsRunning", false);
        }
    }

    public void PermitirMovimiento()
    {
        if (!estaMuerto)
        {
            puedeMoverse = true;
        }
    }

    public void Morir()
    {
        estaMuerto = true;
        puedeMoverse = false;
        rigidBody.velocity = Vector2.zero;

        if (animator != null)
        {
            animator.SetBool("IsRunning", false);
            animator.SetBool("IsJumping", false);
            animator.SetTrigger("IsDead");
        }
    }

    public bool EstaEnSuelo()
    {
        RaycastHit2D raycastHit = Physics2D.BoxCast(
            boxCollider.bounds.center,
            new Vector2(boxCollider.bounds.size.x * 0.9f, boxCollider.bounds.size.y),
            0f,
            Vector2.down,
            0.3f,
            capaSuelo
        );

        return raycastHit.collider != null;
    }

    private void ProcesarMovimiento()
    {
        if (!puedeMoverse)
        {
            return;
        }

        rigidBody.velocity = new Vector2(inputMovimiento * velocidad, rigidBody.velocity.y);
        GestionarOrientacion(inputMovimiento);
    }

    private void ProcesarSalto()
    {
        bool estaEnSuelo = EstaEnSuelo();

        if (estaEnSuelo)
        {
            saltosRestantes = saltosMaximos;
        }

        if (Input.GetKeyDown(KeyCode.Space) && saltosRestantes > 0)
        {
            saltosRestantes--;
            rigidBody.velocity = new Vector2(rigidBody.velocity.x, 0f);
            rigidBody.AddForce(Vector2.up * fuerzaSalto, ForceMode2D.Impulse);

            if (audioManager != null && sonidoSalto != null)
            {
                audioManager.ReproducirSonido(sonidoSalto);
            }
        }
    }

    private void ActualizarAnimaciones()
    {
        if (animator == null)
        {
            return;
        }

        bool estaEnSuelo = EstaEnSuelo();
        bool seEstaMoviendo = Mathf.Abs(inputMovimiento) > 0.01f;

        // Importante: no se puede correr en el aire.
        // Esto evita el error de ver la animacion de carrera durante el salto.
        animator.SetBool("IsRunning", seEstaMoviendo && estaEnSuelo && puedeMoverse);

        // Mientras no toque el suelo, debe verse salto/caida aunque el jugador siga pulsando direccion.
        animator.SetBool("IsJumping", !estaEnSuelo);
    }

    private void GestionarOrientacion(float direccion)
    {
        if ((mirandoDerecha && direccion < 0f) || (!mirandoDerecha && direccion > 0f))
        {
            mirandoDerecha = !mirandoDerecha;
            transform.localScale = new Vector2(-transform.localScale.x, transform.localScale.y);
        }
    }
}
