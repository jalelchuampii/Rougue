using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("UI")]
    [SerializeField] private GameObject deathOverlay;
    [SerializeField] private GameObject victoryPanel;

    [Header("Configuración de nivel")]
    [SerializeField] private float tiempoMostrarMuerte = 1f;

    private int puntosTotales;
    private bool juegoTerminado;

    public int PuntosTotales => puntosTotales;
    public bool JuegoTerminado => juegoTerminado;

    // Compatibilidad con scripts antiguos: la vida real está en PlayerHealth.
    public int vidas => PlayerHealth.Instance != null ? PlayerHealth.Instance.VidasActuales : 0;
    public int vidasMaximas => PlayerHealth.Instance != null ? PlayerHealth.Instance.VidasMaximas : 0;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        Time.timeScale = 1f;
    }

    private void Start()
    {
        if (deathOverlay != null)
        {
            deathOverlay.SetActive(false);
        }

        if (victoryPanel != null)
        {
            victoryPanel.SetActive(false);
        }
        Time.timeScale = 1f;
    }

    public void SumarPuntos(int puntosASumar)
    {
        if (puntosASumar <= 0 || juegoTerminado)
        {
            return;
        }

        puntosTotales += puntosASumar;
        ActualizarHUD();
    }

    public bool GastarPuntos(int cantidad)
    {
        if (cantidad <= 0 || juegoTerminado)
        {
            return false;
        }

        if (puntosTotales < cantidad)
        {
            return false;
        }

        puntosTotales -= cantidad;
        ActualizarHUD();
        return true;
    }

    public void GameOver()
    {
        if (juegoTerminado)
        {
            return;
        }

        StartCoroutine(MostrarGameOver());
    }

    public void Victoria()
    {
        if (juegoTerminado)
        {
            return;
        }

        juegoTerminado = true;

        if (victoryPanel != null)
        {
            victoryPanel.SetActive(true);
        }

        Time.timeScale = 0f;
    }

    // Alias por si prefieres llamar al método en inglés desde algún botón/script.
   public void Victory()
{
   if (victoryPanel != null)
       victoryPanel.SetActive(true);

   Time.timeScale = 0f;
}


    // Métodos puente para que cualquier script antiguo siga funcionando,
    // pero sin volver a guardar vidas dentro del GameManager.
    public void PerderVida()
    {
        if (PlayerHealth.Instance != null)
        {
            PlayerHealth.Instance.RecibirDaño();
        }
    }

    public bool RecuperarVida()
    {
        return PlayerHealth.Instance != null && PlayerHealth.Instance.RecuperarVida();
    }

    public void AumentarVidaMaxima(int cantidad)
    {
        if (PlayerHealth.Instance != null)
        {
            PlayerHealth.Instance.AumentarVidaMaxima(cantidad);
        }
    }

    public void Reintentar()
    {
        Time.timeScale = 1f;
        Scene escenaActual = SceneManager.GetActiveScene();
        SceneManager.LoadScene(escenaActual.buildIndex);
    }

    public void VolverAlInicio()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
    }

    private IEnumerator MostrarGameOver()
    {
        juegoTerminado = true;
        yield return new WaitForSeconds(tiempoMostrarMuerte);

        if (deathOverlay != null)
        {
            deathOverlay.SetActive(true);
        }

        Time.timeScale = 0f;
    }

    private void ActualizarHUD()
    {
        if (HUD.Instance != null)
        {
            HUD.Instance.ActualizarPuntos(puntosTotales);
        }
    }


}
